import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  fullname:any[]=[];
  password:any[]=[];

  check(fullname , password){
    if (fullname!="admin" && password!="admin") {
      var url = 'http://localhost:4200/homepage';
      window.open(url);
    }
    else {
      alert("Error Password or Username")
    }
  }

}
